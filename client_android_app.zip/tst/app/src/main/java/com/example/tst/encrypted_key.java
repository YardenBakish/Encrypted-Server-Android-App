package com.example.tst;

import java.math.BigInteger;
import java.net.Socket;

import android.os.Parcel;
import android.os.Parcelable;

class encrypted_key implements Parcelable {
    static Socket socket;
    static BigInteger Adash;
    public encrypted_key(Socket socket, BigInteger Adash){
        this.socket= socket;
        this.Adash= Adash;
    }

    public encrypted_key(Parcel in) {
    }

    public static final Creator<encrypted_key> CREATOR = new Creator<encrypted_key>() {
        @Override
        public encrypted_key createFromParcel(Parcel in) {
            return new encrypted_key(in);
        }

        @Override
        public encrypted_key[] newArray(int size) {
            return new encrypted_key[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
    }
}