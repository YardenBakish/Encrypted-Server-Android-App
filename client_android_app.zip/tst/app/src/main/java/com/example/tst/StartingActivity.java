package com.example.tst;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidParameterSpecException;
import java.util.Random;
import javax.crypto.spec.DHParameterSpec;


public class StartingActivity extends AppCompatActivity {

    private Thread DHThread;
    public BigInteger Adash;
    public Socket socket;
    public DH ex;
    private EditText IP;
    private EditText port;
    public  boolean InvalidArguments = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starting);
        IP = findViewById(R.id.IP);
        port = findViewById(R.id.PORT);
    }

    public void onClick(View view) throws Exception {
        if (view.getId() == R.id.sec) {
            encrypted_key key;
            ex = new DH();
            DHThread = new Thread(ex);
            DHThread.start();
            DHThread.join();

            if(InvalidArguments){
                Toast.makeText(getApplicationContext(), "Invalid Arguments!", Toast.LENGTH_SHORT).show();
            }
            else if ((Adash!=null) && (socket!=null) && (socket.isConnected())){
                key = new encrypted_key(socket, Adash);
                openMainActivity(key);
            }
            else{
                Toast.makeText(getApplicationContext(), "SERVER IS DOWN!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void openMainActivity(encrypted_key key) {
        Intent intent = new Intent(StartingActivity.this, MainActivity.class);
        intent.putExtra("key", key);
        startActivity(intent);
        finish();
    }

    class DH implements Runnable {
        public void run() {
            try {
                String ip_address= IP.getText().toString().trim();
                String port_str = port.getText().toString().trim();
                if ((ip_address.equals("")) || (port_str.equals(""))) {
                    IOException e = new IOException();
                    throw e;
                }
                InvalidArguments = false;
                int port_num= Integer.parseInt(port.getText().toString().trim());
                InetSocketAddress inetAddress = new InetSocketAddress(ip_address, port_num);
                socket = new Socket();
                socket.connect(inetAddress, 2000);
                if (!socket.isConnected()) {
                    return;
                }
                else{
                    AlgorithmParameterGenerator paramGen = null;
                    try {
                        paramGen = AlgorithmParameterGenerator.getInstance("DH");
                    } catch (NoSuchAlgorithmException e) {
                        e.printStackTrace();
                    }
                    paramGen.init(256, new SecureRandom());
                    AlgorithmParameters params = paramGen.generateParameters();
                    DHParameterSpec dhSpec = null;
                    try {
                        dhSpec = (DHParameterSpec) params.getParameterSpec(DHParameterSpec.class);
                    } catch (InvalidParameterSpecException e) {
                        e.printStackTrace();
                    }
                    Random randomGenerator = new Random();
                    BigInteger rand_intA = new BigInteger(1024, randomGenerator); // secret key a (private) (on server)
                    BigInteger rand_intG = dhSpec.getG(); // prime number (public) (generated on server)
                    BigInteger rand_intP = dhSpec.getP();
                    String serverB;

                    if (null != socket) {
                        PrintWriter out;
                        try {
                            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),
                                    true);

                            BigInteger A = rand_intG.modPow(rand_intA, rand_intP);
                            out.println(rand_intP);
                            out.flush();
                            BufferedReader buff = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            serverB = buff.readLine();
                            out.println(rand_intG.toString());
                            out.flush();
                            BufferedReader buff2 = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            serverB = buff2.readLine();
                            out.flush();
                            out.println(A.toString());
                            BufferedReader buff3 = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            serverB = buff3.readLine();
                            while (true) { //spinlock
                                BufferedReader buff0 = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                                serverB = buff0.readLine();
                                //System.out.println(serverB);
                                if (serverB != null) {
                                    break;
                                }
                            }
                            BigInteger b = new BigInteger(serverB);
                            Adash = b.modPow(rand_intA, rand_intP);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }} catch (UnknownHostException exception) {
                exception.printStackTrace();
            } catch (SocketTimeoutException e){
                e.printStackTrace();
            }
            catch (IOException exception) {
                exception.printStackTrace();
            }
        }}}


