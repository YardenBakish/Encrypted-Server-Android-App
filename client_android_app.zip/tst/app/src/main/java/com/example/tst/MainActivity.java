package com.example.tst;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.math.BigInteger;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;

import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
public class MainActivity extends AppCompatActivity {

    private looperThread enc_channel;
    private Thread looper;
    private TextView txtBox;
    private EditText msg_txtView;
    public static BigInteger Adash;
    public static Socket socket;
    public Button snd_button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*Animation*/
        setContentView(R.layout.activity_main);
        RelativeLayout constraintLayout = findViewById(R.id.activity_server);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();
        /*===========*/

        /*Layout Variables*/
        txtBox = findViewById(R.id.txtView);
        msg_txtView = findViewById(R.id.msg_txtView);
        /*===========*/

        /*Communication Variables*/
        encrypted_key key = getIntent().getParcelableExtra("key");
        if (key!=null){
        if (key.Adash!=null)  Adash = key.Adash;
        if (key.socket!=null) socket = key.socket;}
        /*=============*/

         Toast.makeText(getApplicationContext(), "Diffie Hellman SUCCEEDED!", Toast.LENGTH_SHORT).show();
        addListenerOnButton();
    }
    /*=====================*/

    public void addListenerOnButton(){
        snd_button = (Button) findViewById(R.id.sndBtn);
        snd_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*Send Messages & Connect Server*/

                    String clientMessage;
                    clientMessage = msg_txtView.getText().toString().trim();
                    final String clientMessage_f = clientMessage;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            txtBox.append("Client: "+clientMessage_f+"\n");
                        }
                    });
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        if (Adash!=null)  {
                            try {
                                clientMessage = AES.encryptString(msg_txtView.getText().toString().trim(), Adash.toString());
                            } catch (NoSuchAlgorithmException e) {
                                e.printStackTrace();
                            } catch (InvalidKeySpecException e) {
                                e.printStackTrace();
                            } catch (InvalidKeyException e) {
                                e.printStackTrace();
                            } catch (InvalidAlgorithmParameterException e) {
                                e.printStackTrace();
                            } catch (NoSuchPaddingException e) {
                                e.printStackTrace();
                            } catch (IllegalBlockSizeException e) {
                                e.printStackTrace();
                            } catch (BadPaddingException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    if (null == enc_channel) {
                        enc_channel = new looperThread();
                        looper = new Thread(enc_channel);
                        looper.start();

                    }
                    msgToServer(clientMessage);
                }


        });
    }


    void msgToServer(final String message) {
        new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                try {
                    if (null != socket) {
                        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),
                                true);
                        out.println(message);
                        Thread.sleep(100);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /*Client Thread - listening to server*/
    class looperThread implements Runnable {
        private BufferedReader msg_from_server;
        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        public void run() {
            try {
                Thread.sleep(100);
                while (socket.isConnected()) {
                    this.msg_from_server = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    final String message = AES.decryptString(msg_from_server.readLine(), Adash.toString());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            txtBox.append("Server: "+message+"\n");
                        }
                    });
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onResume() {
        super.onResume();
        super.onResume();
        if (null != enc_channel) {

            try {
                msgToServer(AES.encryptString("resumed", Adash.toString()));
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            } catch (InvalidKeySpecException e) {
                e.printStackTrace();
            } catch (InvalidKeyException e) {
                e.printStackTrace();
            } catch (InvalidAlgorithmParameterException e) {
                e.printStackTrace();
            } catch (NoSuchPaddingException e) {
                e.printStackTrace();
            } catch (IllegalBlockSizeException e) {
                e.printStackTrace();
            } catch (BadPaddingException e) {
                e.printStackTrace();
            }

        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onPause() {
        super.onPause();
        if (null != enc_channel) {

            try {
                msgToServer( AES.encryptString("paused", Adash.toString()));
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            } catch (InvalidKeySpecException e) {
                e.printStackTrace();
            } catch (InvalidKeyException e) {
                e.printStackTrace();
            } catch (InvalidAlgorithmParameterException e) {
                e.printStackTrace();
            } catch (NoSuchPaddingException e) {
                e.printStackTrace();
            } catch (IllegalBlockSizeException e) {
                e.printStackTrace();
            } catch (BadPaddingException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != enc_channel) {
            msgToServer("CLIENT DISCONNECTING");
            enc_channel = null;

        }
    }

}



























